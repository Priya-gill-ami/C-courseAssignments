
// Function declarations
float getX();            // Function to get X coordinate
float getY();            // Function to get Y coordinate
float getZ();            // Function to get Z coordinate
float calcDist(float x, float y, float z);  // Function to calculate distance
void dispRes(float distance);  // Function to display result


